</main>
    <footer class="main-footer">
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> ТОВ ПВПНАСОСЕНЕРГОПРОМ. Всі права захищені.</p>
            <div class="footer-contacts">
                <p>Адреса: м. Івано-Франківськ Вул. Коновальця</p>
            </div>
        </div>
    </footer>
</body>
</html>