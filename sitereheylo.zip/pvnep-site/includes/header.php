<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ТОВ ПВПНАСОСЕНЕРГОПРОМ - Надійність у насосному обладнанні</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="main-header">
        <div class="container">
            <div class="logo">
                <a href="#hero">**ПВПНАСОСЕНЕРГОПРОМ**</a>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="#about">Про нас</a></li>
                    <li><a href="#services">Послуги</a></li>
                    <li><a href="#products">Продукція</a></li>
                    <li><a href="#contact">Контакти</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main>